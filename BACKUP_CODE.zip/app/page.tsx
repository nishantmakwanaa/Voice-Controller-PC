"use client"

import App from "../frontend/App"

export default function SyntheticV0PageForDeployment() {
  return <App />
}